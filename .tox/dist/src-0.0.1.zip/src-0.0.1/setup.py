from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description= "Its wine quality package",
    author="vibuverma",
    packages= find_packages(),
    license="MIT",
)